# Math Scanner

Android aplikace, která snímá obrazovku telefonu, přečte příklad/slovní úlohu (OCR)
a zobrazí odpověď v malém přetahovatelném okýnku přes obrazovku (výchozí poloha
vlevo dole).

- **Čisté výrazy** (např. `3*(9+3)`, `12+5*3-2`) se počítají přímo v telefonu, bez internetu.
- **Slovní úlohy** (např. "Jedna návštěva tělocvičny stojí 7 euro...") se pošlou na
  Claude API, protože to obyčejný výpočet nezvládne — potřebuješ k tomu vlastní API klíč.

## Jak z tohohle dostat aplikaci do telefonu (krok za krokem)

### 1. Nainstaluj Android Studio
Stáhni a nainstaluj z https://developer.android.com/studio (zdarma). Při prvním
spuštění nech doinstalovat Android SDK (nabídne to samo).

### 2. Otevři tento projekt
- Rozbal přiložený .zip soubor kamkoli na disk.
- V Android Studiu: **File → Open** → vyber tu rozbalenou složku (tu, kde je
  soubor `settings.gradle`).
- Pokud se zobrazí hláška o chybějícím Gradle wrapperu, klikni na nabídku
  "OK" / "Create Gradle Wrapper" — Android Studio si ho vytvoří samo.
- Počkej, až proběhne "Gradle Sync" (dole ve stavovém řádku). Může to
  při prvním spuštění chvíli trvat (stahují se závislosti).

### 3. (Volitelné) Claude API klíč pro slovní úlohy
- Založ si účet na https://console.anthropic.com a vygeneruj API klíč.
- Klíč vložíš přímo v aplikaci do políčka "Claude API klíč" — netřeba nic
  měnit v kódu. Bez klíče fungují jen čisté matematické výrazy.

### 4. Připoj telefon a nahraj aplikaci
- V telefonu zapni **Nastavení → O telefonu → 7x klepni na "Číslo sestavení"**
  (aktivuje se vývojářský režim), pak **Nastavení → Možnosti pro vývojáře →
  Ladění přes USB** zapni.
- Připoj telefon kabelem k počítači, potvrď na telefonu "Povolit ladění".
- V Android Studiu nahoře vyber svůj telefon a klikni na zelené tlačítko ▶ (Run).

### 5. Použití v telefonu
1. Otevři appku "Math Scanner".
2. Klikni na **"Povolit okno přes obrazovku"** a potvrď v nastavení systému.
3. (Volitelně) vlož Claude API klíč.
4. Klikni na **"Spustit skenování"** a potvrď sdílení obrazovky.
5. Přepni se do jakékoli appky/stránky s příkladem — do ~2,5 vteřiny se
   vlevo dole objeví okýnko s odpovědí. Okýnko můžeš prstem přetáhnout
   kamkoli po obrazovce.
6. Skenování vypneš tlačítkem "Zastavit skenování" v appce.

## Omezení, o kterých bys měl(a) vědět
- **iPhone/iOS toto nepodporuje** — Apple nepovoluje aplikacím kreslit
  trvalé okno přes obrazovku ani snímat obrazovku na pozadí bez viditelného
  indikátoru. Řešení funguje jen na Androidu.
- OCR (ML Kit) čte nejlépe tištěný/digitální text. Ručně psané příklady
  na papíře vyfocené kamerou budou méně spolehlivé.
- Slovní úlohy stojí (velmi málo, řádově setiny centu za dotaz) kredit na
  tvém Anthropic účtu — Claude API není zdarma bez omezení.
- Skenuje se každé 2,5 vteřiny, aby appka zbytečně nevytápěla telefon a
  nevybíjela baterii. Dá se změnit v `ScreenCaptureService.kt`
  (konstanta `SCAN_INTERVAL_MS`).
