package com.example.mathscanner

/**
 * Zkusí z OCR textu vytáhnout a spočítat čistý matematický výraz,
 * např. "3*(9+3)" nebo "12 + 5 * 3 - 2". Slovní úlohy (věty) tenhle
 * parser neřeší - na to slouží ClaudeApi.kt.
 */
object MathSolver {

    /** Vrátí spočítaný výsledek jako String, nebo null, pokud text nevypadá jako čistý výraz. */
    fun trySolveExpression(rawText: String): String? {
        val candidate = extractExpression(rawText) ?: return null
        return try {
            val result = ExpressionParser(candidate).parse()
            formatResult(result)
        } catch (e: Exception) {
            null
        }
    }

    /** Vytáhne nejdelší souvislý úsek, který vypadá jako matematický výraz (čísla, + - * / ^ ( ) , .) */
    private fun extractExpression(text: String): String? {
        val normalized = text
            .replace("x", "*", ignoreCase = false) // časté OCR/zápis "3x4"
            .replace(":", "/")
            .replace(",", ".")
            .replace("−", "-")
            .replace("×", "*")
            .replace("÷", "/")

        val regex = Regex("""[0-9+\-*/^().\s]{3,}""")
        val matches = regex.findAll(normalized).map { it.value.trim() }.toList()
        val best = matches.maxByOrNull { it.count { c -> c.isDigit() } } ?: return null

        // musí obsahovat aspoň jeden operátor a dvě čísla, jinak to není výraz
        if (!best.any { it in "+-*/^" }) return null
        if (best.count { it.isDigit() } < 2) return null
        return best
    }

    private fun formatResult(value: Double): String {
        return if (value == Math.floor(value) && !value.isInfinite()) {
            value.toLong().toString()
        } else {
            String.format("%.4f", value).trimEnd('0').trimEnd('.')
        }
    }
}

/**
 * Malý rekurzivní parser matematických výrazů.
 * Podporuje: + - * / ^, závorky, desetinná čísla, unární mínus.
 */
private class ExpressionParser(private val input: String) {
    private var pos = 0

    fun parse(): Double {
        val result = parseExpression()
        skipSpaces()
        if (pos < input.length) throw IllegalArgumentException("Nezpracovaný zbytek výrazu")
        return result
    }

    private fun parseExpression(): Double {
        var value = parseTerm()
        while (true) {
            skipSpaces()
            when (peek()) {
                '+' -> { pos++; value += parseTerm() }
                '-' -> { pos++; value -= parseTerm() }
                else -> return value
            }
        }
    }

    private fun parseTerm(): Double {
        var value = parsePower()
        while (true) {
            skipSpaces()
            when (peek()) {
                '*' -> { pos++; value *= parsePower() }
                '/' -> { pos++; value /= parsePower() }
                else -> return value
            }
        }
    }

    private fun parsePower(): Double {
        val base = parseUnary()
        skipSpaces()
        if (peek() == '^') {
            pos++
            val exponent = parsePower()
            return Math.pow(base, exponent)
        }
        return base
    }

    private fun parseUnary(): Double {
        skipSpaces()
        if (peek() == '-') { pos++; return -parseUnary() }
        if (peek() == '+') { pos++; return parseUnary() }
        return parseFactor()
    }

    private fun parseFactor(): Double {
        skipSpaces()
        if (peek() == '(') {
            pos++
            val value = parseExpression()
            skipSpaces()
            if (peek() != ')') throw IllegalArgumentException("Chybí uzavírací závorka")
            pos++
            return value
        }
        val start = pos
        while (pos < input.length && (input[pos].isDigit() || input[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("Očekáváno číslo na pozici $pos")
        return input.substring(start, pos).toDouble()
    }

    private fun skipSpaces() {
        while (pos < input.length && input[pos].isWhitespace()) pos++
    }

    private fun peek(): Char = if (pos < input.length) input[pos] else '\u0000'
}
