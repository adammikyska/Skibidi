package com.example.mathscanner

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Pošle text (typicky slovní úlohu, kterou MathSolver nedokázal spočítat sám)
 * na Claude API a vrátí jen samotnou odpověď/číslo.
 *
 * Vyžaduje vlastní API klíč z https://console.anthropic.com
 * (Nastavení -> API klíč v hlavní obrazovce aplikace).
 */
object ClaudeApi {

    // Rychlý a levný model - stačí na aritmetiku a jednoduché slovní úlohy.
    // Pro složitější úlohy lze změnit např. na "claude-sonnet-5".
    private const val MODEL = "claude-haiku-4-5-20251001"

    fun solveWordProblem(apiKey: String, ocrText: String): String {
        val url = URL("https://api.anthropic.com/v1/messages")
        val connection = url.openConnection() as HttpsURLConnection
        connection.requestMethod = "POST"
        connection.setRequestProperty("Content-Type", "application/json")
        connection.setRequestProperty("x-api-key", apiKey)
        connection.setRequestProperty("anthropic-version", "2023-06-01")
        connection.doOutput = true
        connection.connectTimeout = 8000
        connection.readTimeout = 8000

        val systemPrompt =
            "Dostaneš text naskenovaný z obrazovky telefonu (může obsahovat OCR šum). " +
            "Najdi v něm matematický příklad nebo slovní úlohu a spočítej ji. " +
            "Odpověz VÝHRADNĚ konečným výsledkem (číslo, případně s jednotkou), " +
            "žádný postup, žádné vysvětlení, jedna krátká odpověď."

        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", 200)
            put("system", systemPrompt)
            put("messages", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", ocrText)
                }
            ))
        }

        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val responseCode = connection.responseCode
        val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }

        if (responseCode !in 200..299) {
            throw RuntimeException("Claude API chyba ($responseCode): $responseText")
        }

        val json = JSONObject(responseText)
        val content = json.getJSONArray("content")
        val textBlock = content.getJSONObject(0).getString("text")
        return textBlock.trim()
    }
}
